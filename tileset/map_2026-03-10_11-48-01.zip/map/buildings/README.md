# 建筑 Sprite2D 场景

4 个建筑场景，可直接拖入地图使用。

| 场景 | 说明 |
|------|------|
| `lab.tscn` | LAB 建筑 |
| `marie_reay.tscn` | Marie Reay Teaching Centre |
| `subway.tscn` | Subway 餐厅 |
| `chifley.tscn` | J.B. Chifley Library |

## 使用方法

1. 在场景树中，将 `buildings/` 下的场景拖入 `main.tscn`（或任意地图场景）
2. 在 2D 视图中拖动建筑调整位置
3. 如需碰撞检测，可在建筑场景中添加 `Area2D` + `CollisionShape2D`

## 注意

- 所有建筑使用 `centered = false`，锚点在左上角，便于对齐地面
