# Little Dreamyland TileSet 设置说明

根据 [Godot TileSet 教程](https://docs.godotengine.org/en/stable/tutorials/2d/using_tilesets.html#creating-a-new-tileset) 创建的 Little Dreamyland 素材包 TileSet 配置。
