extends Node2D

## Main scene for the map project.
## The TileMapLayer uses the Little Dreamyland TileSet.
